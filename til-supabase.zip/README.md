# MarkDown Editor

- `/src/components/common/board 폴더 생성`
- `/src/components/common/board/BasicBoard.tsx 파일 생성`
- `/src/components/common/board/BasicBoard.module.scss 파일 생성`

# 실습 1.

## 실습 1.1. BasicBoard.tsx

```tsx
import styles from "@/components/common/board/BasicBoard.module.scss";

function BasicBoard() {
  return (
    <div className={styles.container}>
      <div className={styles.container_header}>
        <div className={styles.container_header_titleBox}>
          <span className={styles.title}>
            Please enter a title for your board
          </span>
        </div>
      </div>
      <div className={styles.container_body}></div>
    </div>
  );
}

export default BasicBoard;
```

## 실습 1.2. shadcn/ui Checkbox

- https://ui.shadcn.com/docs/components/checkbox

```bash
npx shadcn@latest add checkbox --legacy-peer-deps
```

## 실습 1.3. BasicBoard.tsx

```tsx
import styles from "@/components/common/board/BasicBoard.module.scss";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronUp } from "lucide-react";

function BasicBoard() {
  return (
    <div className={styles.container}>
      {/* 헤더 */}
      <div className={styles.container_header}>
        <div className={styles.container_header_titleBox}>
          <Checkbox className="w-5 h-5" />
          <span className={styles.title}>
            Please enter a title for your board
          </span>
          <Button variant={"ghost"}>
            <ChevronUp calcMode="w-5 h-5" />
          </Button>
        </div>
      </div>
      {/* 본문 */}
      <div className={styles.container_body}>
        <div className={styles.container_body_calendarBax}>
          캘린더 선택 버튼 작성예정
        </div>
        <div className={styles.container_body_buttonBox}>
          <Button
            variant={"ghost"}
            className="font-normal text-gray-400 hover:bg-green-500 hover:text-white"
          >
            Duplicate
          </Button>
          <Button
            variant={"ghost"}
            className="font-normal text-gray-400 hover:bg-red-500 hover:text-white"
          >
            Delete
          </Button>
        </div>
      </div>
      {/* 하단 */}
      <div className={styles.container_footer}></div>
    </div>
  );
}

export default BasicBoard;
```

## 실습 1.4. BasicBoard.module.scss

```scss
.container {
  display: flex;
  flex-direction: column;
  align-items: center;

  width: 100%;
  padding: 20px;
  background-color: #fff;
  border-radius: 4px;
  box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.2);

  &_header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;

    &_titleBox {
      display: flex;
      align-items: center;
      flex: 1;
      gap: 8px;
      .title {
        width: 100%;
        font-weight: 500;
        font-size: 24px;
        color: #454545;

        &::placeholder {
          font-weight: 500;
          color: #dbdbdb;
        }
      }
    }
  }

  &_body {
    display: flex;
    align-items: center;
    justify-content: space-between;

    width: 100%;
    margin: 24px 0 14px 0;

    &_calendarBox {
      display: flex;
      align-items: center;
      gap: 16px;
    }
  }

  &_footer {
    display: flex;
    align-items: center;
    justify-content: space-between;

    width: 100%;
    padding-top: 14px;
    border-top: 1px solid #bdbdbd;
  }
}
```

## 실습 1.5. Board 화면 출력 페이지 만들기

- http://localhost:3000/create
- /src/app/create 폴더 생성
- /src/app/create/page.tsx 파일 생성
- /src/app/create/page.module.scss 파일 생성

## 실습 1.6. Board 출력

```tsx
import styles from "@/app/create/page.module.scss";
import BasicBoard from "@/components/common/board/BasicBoard";

function Page() {
  return (
    <div className={styles.container}>
      <div className={styles.container_body}>
        <BasicBoard />
      </div>
    </div>
  );
}

export default Page;
```

```scss
.container {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  width: 920px;
  height: 100vh;
  background-color: #f9f9f9;
  border-right: 1px solid #e6e6e6;
}
```

## 실습 1.7. Create 페이지 추가

- https://ui.shadcn.com/docs/components/progress

```bash
 npx shadcn@latest add progress
```

- progress 컴포넌트 props 추가

```tsx
"use client";

import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";

import { cn } from "@/lib/utils";

// 사용자 정의 인터페이스
interface ProgressProps
  extends React.ComponentProps<typeof ProgressPrimitive.Root> {
  indicateColor?: string;
}

function Progress({
  className,
  value,
  indicateColor,
  ...props
}: ProgressProps) {
  return (
    <ProgressPrimitive.Root
      data-slot="progress"
      className={cn(
        "bg-primary/20 relative h-2 w-full overflow-hidden rounded-full",
        className
      )}
      {...props}
    >
      <ProgressPrimitive.Indicator
        data-slot="progress-indicator"
        className={`h-full w-full flex-1 transition-all ${indicateColor && indicateColor}`}
        style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
      />
    </ProgressPrimitive.Root>
  );
}

export { Progress };
```

## 실습 1.8. Create 페이지 출력

```tsx
import styles from "@/app/create/page.module.scss";
import BasicBoard from "@/components/common/board/BasicBoard";
import { Progress } from "@/components/ui/progress";

function Page() {
  return (
    <div className={styles.container}>
      {/* 상단 */}
      <header className={styles.container_header}>
        <div className={styles.container_header_contents}>
          <input
            type="text"
            placeholder="Enter Title Here"
            className={styles.input}
          />
          {/* 진행율 */}
          <div className={styles.progressBar}>
            <span className={styles.progressBar_status}>1/10 completed!</span>
            {/* Progress 컴포넌트 배치 */}
            <Progress
              value={33}
              className="w-[30%] h-2"
              indicateColor="bg-orange-500"
            />
          </div>
          {/* 캘린더 선택 추가 */}
          <div className={styles.calendarBox}>캘린터 선택 버튼</div>
        </div>
      </header>
      {/* 본문 */}
      <div className={styles.container_body}>
        <BasicBoard />
      </div>
    </div>
  );
}

export default Page;
```

## 실습 1.9. Create 페이지 SCSS 작업

```scss
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 920px;
  height: 100vh;
  background-color: #f9f9f9;
  border-right: 1px solid #e6e6e6;

  &_header {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    width: 100%;
    background-color: #fff;

    &_contents {
      width: 100%;
      padding: 20px 28px;
      margin-top: 68px;

      .input {
        font-size: 36px;
        font-weight: 700;
        outline: none;

        &::placeholder {
          color: #c4c4c4;
        }
      }

      .progressBar {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: flex-start;

        gap: 16px;
        margin: 8px 0 16px 0;

        &_status {
          color: #6d6d6d;
          font-size: 14px;
        }
      }

      .calendarBox {
        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 20px;

        &_calendar {
          display: flex;
          align-items: center;
          gap: 20px;
        }
      }
    }
  }
  &_body {
    display: flex;
    align-items: flex-start; // 추후 수정
    justify-content: center;

    width: 100%;
    height: calc(100vh - 250px);

    padding: 28px 16px;

    &_infoBox {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;

      .title {
        font-size: 24px;
        font-weight: 700;
        color: #454545;
      }

      .subTitle {
        margin: 14px 0 28px 0;
        font-size: 18px;
        color: #454545;
      }

      .button {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 74px;
        height: 74px;

        outline: none;
        border: none;
        cursor: pointer;
      }
    }
  }
}
```

## 실습 1.10. shadcn/ui Calendar 컴포넌트

- https://ui.shadcn.com/docs/components/calendar

```bash
npx shadcn@latest add calendar
```

- `/src/components/common/calendar 폴더` 생성
- `/src/components/common/calendar/LabelCalendar.tsx 파일` 생성
- `/src/components/common/calendar/LabelCalendar.module.scss 파일` 생성
