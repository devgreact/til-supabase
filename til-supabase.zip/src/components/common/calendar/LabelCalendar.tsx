import styles from "@/components/common/calendar/LabelCalendar.module.scss";

interface LabelCalendarProps {
  label: string;
  required: boolean;
}

function LabelCalendar({ label, required }: LabelCalendarProps) {
  return <div>{label}</div>;
}

export default LabelCalendar;
