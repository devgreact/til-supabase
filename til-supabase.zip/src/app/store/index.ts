import { atom } from "jotai";
// 상태값 저장 구분용 변수
export const sidebarStateAtom = atom<string>("");
